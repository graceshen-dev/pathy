<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Students apply on time to the universities they really want.

## Metric

Applications with every checklist item completed before the official deadline each month
