import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';
import { reflectionComplete, type Reflection } from '@/lib/campus-reflection';
import { visitedCampusIds } from '@/lib/journey-personalization';
export type Preferences = { name: string; program: string; city: string; saved: string[]; visited: string[]; selected: string; todoDone: Record<string, boolean>; todoDates: Record<string, string>; quizStamps: string[]; myApps: { id: string; university_id: string; program: string }[]; reflections: Record<string, Reflection> };
const initial: Preferences = { name: '', program: '', city: 'Toronto', saved: [], visited: [], selected: 'waterloo', todoDone: {}, todoDates: {}, quizStamps: [], myApps: [], reflections: {} };
type Journey = { preferences: Preferences; update: (patch: Partial<Preferences>) => void; applications: Tables<'applications'>[]; tasks: Tables<'application_tasks'>[]; stamps: Tables<'passport_entries'>[]; loading: boolean; error: string; signedIn: boolean; mentors: Tables<'profiles'>[]; userId: string; visit: (id: string) => void; earnStamp: (id: string, reflection: Reflection) => boolean };
const JourneyContext = createContext<Journey | null>(null);
export function JourneyProvider({ children }: { children: ReactNode }) {
 const [preferences, setPreferences] = useState(initial); const [key, setKey] = useState(''); const [loading, setLoading] = useState(true); const [error, setError] = useState(''); const [signedIn, setSignedIn] = useState(false);
 const [userId, setUserId] = useState(''); const [mentors, setMentors] = useState<Tables<'profiles'>[]>([]);
 const [applications, setApplications] = useState<Tables<'applications'>[]>([]); const [tasks, setTasks] = useState<Tables<'application_tasks'>[]>([]); const [stamps, setStamps] = useState<Tables<'passport_entries'>[]>([]);
 useEffect(() => {
  let active = true;
  async function load() {
   setLoading(true); setError('');
   try {
    const { data: { session } } = await supabase.auth.getSession(); if (!active) return;
    const storageKey = `pathfinder-journey-${session?.user.id ?? 'guest'}`; setKey(storageKey); setSignedIn(Boolean(session)); setUserId(session?.user.id ?? '');
    let stored: Partial<Preferences> = {}; try { stored = JSON.parse(localStorage.getItem(storageKey) ?? '{}'); } catch { /* Invalid local preferences are ignored. */ }
    if (!session) { setPreferences({ ...initial, ...stored }); setApplications([]); setTasks([]); setStamps([]); setMentors([]); return; }
    const uid = session.user.id;
    const [profile, apps, taskRows, stampRows, mentorRows] = await Promise.all([supabase.from('profiles').select('*').eq('id', uid).maybeSingle(), supabase.from('applications').select('*').eq('user_id', uid), supabase.from('application_tasks').select('*').eq('user_id', uid), supabase.from('passport_entries').select('*').eq('user_id', uid), supabase.from('profiles').select('*').eq('role', 'mentor')]);
    if (!active) return;
    setPreferences({ ...initial, name: profile.data?.full_name ?? '', program: profile.data?.interests ?? profile.data?.program ?? '', ...stored, visited: visitedCampusIds(stored.visited ?? [], stampRows.data ?? []) });
    setMentors(mentorRows.data ?? []); setApplications(apps.data ?? []); setTasks(taskRows.data ?? []); setStamps(stampRows.data ?? []);
    if ([profile, apps, taskRows, stampRows, mentorRows].some(r => r.error)) setError('Some saved journey details could not be loaded.');
   } catch { if (active) setError('Your saved journey could not be loaded. You can still explore campuses.'); }
   finally { if (active) setLoading(false); }
  }
  void load(); const { data } = supabase.auth.onAuthStateChange(() => { void load(); });
  return () => { active = false; data.subscription.unsubscribe(); };
 }, []);
 function visit(id: string) { setPreferences(current => { const next = { ...current, selected: id, visited: visitedCampusIds([...current.visited, id], stamps) }; if (key) { try { localStorage.setItem(key, JSON.stringify(next)); } catch { setError('This campus exploration could not be saved on your device.'); } } return next; }); }
 function earnStamp(id: string, reflection: Reflection) { if (!reflectionComplete(reflection)) return false; setPreferences(current => { const next = { ...current, quizStamps: [...new Set([...current.quizStamps, id])], reflections: { ...current.reflections, [id]: reflection } }; if (key) { try { localStorage.setItem(key, JSON.stringify(next)); } catch { setError('Your stamp could not be saved on this device.'); } } return next; }); return true; }
 function update(patch: Partial<Preferences>) { setPreferences(current => { const next = { ...current, ...patch }; if (key) { try { localStorage.setItem(key, JSON.stringify(next)); } catch { setError('Your preferences could not be saved on this device.'); } } return next; }); }
 return <JourneyContext.Provider value={{ preferences, update, applications: [...applications, ...preferences.myApps.map(a => ({ ...a, user_id: userId || 'device', applied_on: '', created_at: '' }))], tasks, stamps, loading, error, signedIn, mentors, userId, visit, earnStamp }}>{children}</JourneyContext.Provider>;
}
export function useJourney() { const value = useContext(JourneyContext); if (!value) throw new Error('JourneyProvider is required'); return value; }
