import { resolveCampus } from './campuses';
import { checklistDeadlines, ouacEqualConsideration } from './official-deadlines';
import type { Tables } from '@/integrations/supabase/types';
export type Application = Tables<'applications'>;
export type JourneyTodo = { id: string; title: string; completed: boolean; due_date: string | null; suggested: boolean; deadlineSource?: string | undefined; deadlineUrl?: string | undefined };
export function programTodos(program: string): string[] {
 const p = program.toLowerCase();
 const items = /math|statistics|actuarial/.test(p) ? ['Review calculus and advanced-functions prerequisites', 'Compare pure math, statistics, and co-op pathways', 'Prepare questions about first-year math courses']
 : /engineering/.test(p) ? ['Review math, physics, and chemistry prerequisites', 'Check whether an engineering interview or supplement is required', 'Compare design projects and engineering co-op options']
 : /computer|computing|software/.test(p) ? ['Review math prerequisites for computing', 'Compare programming courses and co-op options', 'Check whether a computing supplement is required']
 : /health|nursing|science|biology/.test(p) ? ['Review science prerequisites for your chosen stream', 'Check whether a science or health supplement is required', 'Compare lab, placement, and research opportunities']
 : /business|commerce|management/.test(p) ? ['Review math prerequisites for business', 'Check whether a business interview or supplement is required', 'Prepare examples of leadership and community involvement']
 : /art|design|music/.test(p) ? ['Check whether a portfolio or audition is required', 'Review your program’s first-year courses', 'Prepare questions about studios and creative opportunities']
 : ['Review your program’s prerequisites', 'Check whether supplemental materials are required', 'Compare first-year courses and experiential learning'];
 return items.map(item => `${item} · ${program}`);
}
export function applicationTodos(app: Application, tasks: Tables<'application_tasks'>[], overrides: Record<string, boolean> = {}): JourneyTodo[] {
 const deadlines = checklistDeadlines(app.university_id, app.program);
 const first = deadlines[0] ?? ouacEqualConsideration;
 const existing = tasks.filter(t => t.application_id === app.id);
 const saved = existing.map(t => ({ ...t, completed: overrides[t.id] ?? t.completed, suggested: false, due_date: t.due_date ?? first.date, deadlineSource: t.due_date ? undefined : first.sourceName, deadlineUrl: t.due_date ? undefined : first.source }));
 const official = deadlines.filter(d => !existing.some(t => t.title.toLowerCase() === d.title.toLowerCase())).map(d => { const id = `${app.id}:deadline:${d.id}`; return { id, title: d.title, completed: overrides[id] ?? false, due_date: d.date, suggested: false, deadlineSource: d.sourceName, deadlineUrl: d.source }; });
 // Preparation items must be done before the first official deadline, so they inherit it.
 const suggested = programTodos(app.program).filter(title => !existing.some(t => t.title.toLowerCase() === title.toLowerCase())).map((title, i) => {
  const id = `${app.id}:program:${i}`;
  return { id, title, completed: overrides[id] ?? false, due_date: first.date, suggested: true, deadlineSource: first.sourceName, deadlineUrl: first.source };
 });
 return [...official, ...saved, ...suggested].sort((a, b) => (a.due_date ?? '').localeCompare(b.due_date ?? ''));
}
export function campusKey(id: string) { return resolveCampus(id)?.id ?? id; }
export function visitedCampusIds(visited: string[], stamps: Pick<Tables<'passport_entries'>, 'university_id'>[]) {
 return [...new Set([...stamps.map(s => campusKey(s.university_id)), ...visited.map(campusKey)])];
}
export type MentorMatch = { id: string; name: string; university_id: string; program: string; year: string; bio: string; ai: boolean; portraitIndex: number };
export function mentorsForApplication(app: Application, profiles: Tables<'profiles'>[]): MentorMatch[] {
 const real = profiles.filter(p => p.role === 'mentor' && p.full_name.trim() && p.program?.trim().toLowerCase() === app.program.trim().toLowerCase() && p.university_id && campusKey(p.university_id) === campusKey(app.university_id)).slice(0, 3).map(p => ({ id: p.id, name: p.full_name, university_id: app.university_id, program: app.program, year: p.year ?? 'Student mentor', bio: p.bio ?? 'Ask about their experience in your program.', ai: false, portraitIndex: -1 }));
 return [...real, ...['Aisha', 'Daniel', 'Priya'].slice(0, 3 - real.length).map((name, i) => ({ id: `${app.id}:ai:${i}`, name, university_id: app.university_id, program: app.program, year: `Year ${i + 2}`, bio: ['Curious about co-op, campus life, and finding your people.', 'A friendly perspective on first-year courses and study routines.', 'Interested in clubs, community, and the first-gen experience.'][i] ?? '', ai: true, portraitIndex: i }))];
}
