import type { JourneyTodo } from './journey-personalization';
export function checklistPercent(todos: Pick<JourneyTodo, 'completed'>[]) { return todos.length ? Math.round(todos.filter(t => t.completed).length / todos.length * 100) : 0; }
export function todoDueDate(todo: Pick<JourneyTodo, 'id' | 'due_date'>, dates: Record<string, string>) { return dates[todo.id] ?? todo.due_date ?? ''; }
export function formatDueDate(value: string) { const date = new Date(`${value.slice(0, 10)}T12:00:00`); return Number.isNaN(date.getTime()) ? 'Date not set' : date.toLocaleDateString('en-CA', { month: 'short', day: 'numeric', year: 'numeric' }); }
