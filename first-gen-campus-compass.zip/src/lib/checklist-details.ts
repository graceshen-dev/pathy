import type { JourneyTodo } from './journey-personalization';
export function checklistPercent(todos: Pick<JourneyTodo, 'completed'>[]) { return todos.length ? Math.round(todos.filter(t => t.completed).length / todos.length * 100) : 0; }
// Due dates come only from official deadlines attached to the checklist item; students cannot override them.
export function todoDueDate(todo: Pick<JourneyTodo, 'due_date'>) { return todo.due_date ?? ''; }
export function formatDueDate(value: string) { const date = new Date(`${value.slice(0, 10)}T12:00:00`); return Number.isNaN(date.getTime()) ? 'Date not set' : date.toLocaleDateString('en-CA', { month: 'short', day: 'numeric', year: 'numeric' }); }
