import { resolveCampus } from './campuses';

export type OfficialDeadline = { id: string; title: string; date: string; audience: string; source: string; sourceName: string };
export const deadlineIntake = 'Fall 2027';
export const deadlinesCheckedOn = '2026-11-07';
const waterlooMathDeadlines: OfficialDeadline[] = [
 { id: 'ouac-group-a', title: 'Submit your OUAC application', date: '2027-01-15', audience: 'Ontario high school applicants (OUAC Group A)', source: 'https://www.ouac.on.ca/guide/undergrad-dates/', sourceName: 'OUAC key dates' },
 { id: 'waterloo-application', title: 'Waterloo application deadline', date: '2027-02-01', audience: 'Waterloo programs other than Engineering; Group A applicants should use the earlier January 15 OUAC deadline', source: 'https://uwaterloo.ca/future-students/admissions/deadlines', sourceName: 'Waterloo application deadlines' },
 { id: 'waterloo-aif', title: 'Submit your Admission Information Form (AIF)', date: '2027-02-15', audience: 'Faculty of Mathematics applicants; the AIF is required', source: 'https://uwaterloo.ca/future-students/admissions/admission-information-form', sourceName: 'Waterloo AIF deadlines' },
 { id: 'waterloo-documents', title: 'Submit required supporting documents', date: '2027-02-15', audience: 'Programs other than Engineering; check your applicant portal for required documents', source: 'https://uwaterloo.ca/future-students/admissions/deadlines', sourceName: 'Waterloo document deadlines' },
];
export function officialDeadlinesFor(universityId: string, program: string): OfficialDeadline[] {
 if (resolveCampus(universityId)?.id !== 'waterloo' || !/\b(math|mathematics)\b/i.test(program)) return [];
 return waterlooMathDeadlines;
}