import { campuses } from './campuses';
export type QuizQuestion = { question: string; options: string[]; answer: number; explanation: string };
const highlights: Record<string, { question: string; options: string[]; answer: number; explanation: string }> = {
 waterloo: { question: 'Which learning pathway is Waterloo especially known for?', options: ['Co-op work terms', 'Only online courses', 'No work experience'], answer: 0, explanation: 'Waterloo is known for co-op programs that combine study with work terms.' },
 uoft: { question: 'What kind of setting is the St. George campus in?', options: ['A remote island', 'Downtown Toronto', 'A desert'], answer: 1, explanation: 'The St. George campus is in downtown Toronto.' },
 mcmaster: { question: 'Which city would you explore around McMaster’s main campus?', options: ['Ottawa', 'Vancouver', 'Hamilton'], answer: 2, explanation: 'McMaster’s main campus is in Hamilton, Ontario.' },
 york: { question: 'What is the name of the York campus shown on this map?', options: ['Keele campus', 'St. George campus', 'West Point campus'], answer: 0, explanation: 'The map shows York’s Keele campus in Toronto.' },
 guelph: { question: 'Which city shares its name with this university?', options: ['Kingston', 'Guelph', 'London'], answer: 1, explanation: 'The University of Guelph is in Guelph, Ontario.' },
};
export function campusQuiz(id: string): QuizQuestion[] {
 const c = campuses.find(c => c.id === id); if (!c) return [];
 const highlight = highlights[id] ?? { question: `Which area of study can you explore at ${c.short}?`, options: [c.programs[0] ?? 'Arts', 'Only deep-sea diving', 'Only astronaut training'], answer: 0, explanation: `${c.short} offers programs in ${c.programs[0] ?? 'Arts'}. Check its official website for current options.` };
 const otherCities = ['Ottawa', 'Thunder Bay', 'London'].filter(city => city !== c.city).slice(0, 2);
 return [
  { question: `In which Ontario city is the ${c.short} campus shown on this map?`, options: [c.city, ...otherCities], answer: 0, explanation: `The campus shown for ${c.name} is in ${c.city}, Ontario.` },
  highlight,
  { question: `Where should you check current ${c.short} program requirements?`, options: ['An unverified social post', 'Last year’s group chat', 'The university’s official admissions website'], answer: 2, explanation: 'Always confirm prerequisites and deadlines on the university’s official admissions website.' },
 ];
}
export function quizPassed(id: string, answers: number[]) { const questions = campusQuiz(id); return questions.length === 3 && answers.length === 3 && questions.every((q, i) => answers[i] === q.answer); }
