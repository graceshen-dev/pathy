import waterloo from '@/assets/waterloo-campus.jpg.asset.json';
import uoft from '@/assets/uoft-campus.jpg.asset.json';
import mcmaster from '@/assets/mcmaster-campus.jpg.asset.json';
import york from '@/assets/york-campus.jpg.asset.json';
import guelph from '@/assets/guelph-campus.jpg.asset.json';
export const campusPhotos: Record<string, { url: string; alt: string; credit: string; source: string }> = {
 waterloo: { url: waterloo.url, alt: 'Students beside the University of Waterloo campus sign', credit: 'University of Waterloo', source: 'https://uwaterloo.ca/future-students/' },
 uoft: { url: uoft.url, alt: 'University College and the lawn at Toronto’s St. George campus', credit: 'University of Toronto', source: 'https://future.utoronto.ca/' },
 mcmaster: { url: mcmaster.url, alt: 'The McMaster University archway and campus buildings', credit: 'McMaster University', source: 'https://discover.mcmaster.ca/' },
 york: { url: york.url, alt: 'An aerial view of York University’s Keele campus', credit: 'York University', source: 'https://futurestudents.yorku.ca/' },
 guelph: { url: guelph.url, alt: 'The Gryphon statue and students at the University of Guelph', credit: 'University of Guelph', source: 'https://www.uoguelph.ca/' },
};
