import waterloo from '@/assets/waterloo-campus.jpg.asset.json';
import uoft from '@/assets/uoft-campus.jpg.asset.json';
import mcmaster from '@/assets/mcmaster-campus.jpg.asset.json';
import york from '@/assets/york-campus.jpg.asset.json';
import guelph from '@/assets/guelph-campus.jpg.asset.json';
export const campusPhotos: Record<string, { url: string; alt: string; credit: string; source: string }> = {
 waterloo: { url: waterloo.url, alt: 'Dana Porter Library at the University of Waterloo', credit: 'Wikimedia Commons', source: 'https://commons.wikimedia.org/wiki/File:Dana_Porter_Library_-_Waterloo,_ON.jpg' },
 uoft: { url: uoft.url, alt: 'University College at Toronto’s St. George campus', credit: 'Wikimedia Commons', source: 'https://commons.wikimedia.org/wiki/File:University_College,_University_of_Toronto,_Canada.jpg' },
 mcmaster: { url: mcmaster.url, alt: 'University Hall at McMaster University', credit: 'Wikimedia Commons', source: 'https://commons.wikimedia.org/wiki/File:University_Hall_McMaster_2013.jpg' },
 york: { url: york.url, alt: 'Vari Hall on York University’s Keele campus', credit: 'Wikimedia Commons', source: 'https://commons.wikimedia.org/wiki/File:Vari_Hall.jpg' },
 guelph: { url: guelph.url, alt: 'Johnston Hall across Johnston Green at the University of Guelph', credit: 'Wikimedia Commons', source: 'https://commons.wikimedia.org/wiki/File:20150703_-_05_-_Guelph,_Ont._-_Johnston_Hall_as_seen_from_across_Johnston_Green,_University_of_Guelph.jpg' },
};
