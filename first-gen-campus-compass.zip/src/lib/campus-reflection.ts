import { campusFacts } from './campus-facts';
// Short "check-in" that replaces the multiple-choice quiz: two taps help a student remember a campus.
export type Reflection = { standout: string; program: string; note: string; date: string };
export const standoutOptions = ['The campus vibe', 'The buildings', 'The city', 'Student life', 'Co-op & careers', 'Sports & clubs', 'Size of the school', 'Location near home'];
export function reflectionComplete(r: Partial<Reflection>) { return Boolean(r.standout?.trim() && r.program?.trim()); }
export function campusFunFact(id: string) { return campusFacts[id]?.fact.detail ?? ''; }
