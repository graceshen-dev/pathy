import { describe, expect, it } from 'vitest';
import { reflectionComplete } from '@/lib/campus-reflection';
describe('Campus check-in stamp rule', () => {
 it('needs both what stood out and a program before Pat stamps', () => {
  expect(reflectionComplete({ standout: 'The city', program: 'Business' })).toBe(true);
  expect(reflectionComplete({ standout: 'The city', program: '' })).toBe(false);
  expect(reflectionComplete({ standout: '', program: 'Business' })).toBe(false);
 });
});
