import { describe, expect, it } from 'vitest';
import { campuses, matchedCampuses, resolveCampus } from '@/lib/campuses';
describe('Geographic campus exploration', () => {
 it('places Waterloo at its campus coordinates', () => {
  expect(campuses.find(c => c.id === 'waterloo')).toMatchObject({ lat: 43.4723, lng: -80.5449 });
 });
 it('filters campuses to the selected program', () => {
   expect(matchedCampuses('Engineering').map(c => c.id)).toEqual(['waterloo', 'uoft', 'mcmaster', 'york', 'carleton', 'lakehead', 'laurentian', 'ontariotech', 'ottawa', 'queens', 'tmu', 'western', 'windsor']);
 });
 it('includes all 23 publicly assisted Ontario universities with unique geographic entries', () => {
  expect(campuses.map(c => c.id).sort()).toEqual(['algoma','brock','carleton','guelph','hearst','lakehead','laurentian','laurier','mcmaster','nipissing','nosm','ocad','ontariotech','ottawa','queens','tmu','trent','uoft','uof','waterloo','western','windsor','york'].sort());
  expect(campuses.every(c => c.lat > 41 && c.lat < 57 && c.lng > -95 && c.lng < -74)).toBe(true);
 });
 it('distinguishes Toronto universities and resolves French names and former names', () => {
  expect(resolveCampus('Toronto Metropolitan University')?.id).toBe('tmu');
  expect(resolveCampus('Université de l’Ontario français')?.id).toBe('uof');
  expect(resolveCampus('University of Toronto')?.id).toBe('uoft');
  expect(resolveCampus('Ryerson University')?.id).toBe('tmu');
 });
});