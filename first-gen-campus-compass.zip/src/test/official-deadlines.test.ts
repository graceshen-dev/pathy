import { describe, expect, it } from 'vitest';
import { deadlineIntake, officialDeadlinesFor } from '@/lib/official-deadlines';

describe('Verified Fall 2027 Waterloo Mathematics deadlines', () => {
 const dates = officialDeadlinesFor('waterloo', 'Honours Math');
 it('keeps the intake explicit', () => { expect(deadlineIntake).toBe('Fall 2027'); });
 it('uses the January 15 OUAC Group A application deadline', () => { expect(dates.find(d => d.id === 'ouac-group-a')?.date).toBe('2027-01-15'); });
 it('uses the February 1 Waterloo non-Engineering application deadline', () => { expect(dates.find(d => d.id === 'waterloo-application')?.date).toBe('2027-02-01'); });
 it('uses the February 15 Mathematics AIF deadline', () => { expect(dates.find(d => d.id === 'waterloo-aif')?.date).toBe('2027-02-15'); });
 it('uses the February 15 supporting documents deadline', () => { expect(dates.find(d => d.id === 'waterloo-documents')?.date).toBe('2027-02-15'); });
 it('does not assign Mathematics dates to other programs or universities', () => {
  expect(officialDeadlinesFor('waterloo','Engineering')).toEqual([]);
  expect(officialDeadlinesFor('uoft','Honours Math')).toEqual([]);
 });
});