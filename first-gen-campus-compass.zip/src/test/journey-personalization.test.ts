import { describe, expect, it } from 'vitest';
import { applicationTodos, mentorsForApplication, visitedCampusIds } from '@/lib/journey-personalization';
import type { Tables } from '@/integrations/supabase/types';
const app: Tables<'applications'> = { id: 'math-app', university_id: 'waterloo', program: 'Honours Math', user_id: 'student', applied_on: '', created_at: '' };
describe('Application-based journey', () => {
 it('creates math-specific to-dos for the applied program', () => {
  const todos = applicationTodos(app, []);
  expect(todos.find(t => t.suggested)?.title).toBe('Review calculus and advanced-functions prerequisites · Honours Math');
  expect(todos.every(t => !t.completed)).toBe(true);
 });
 it('excludes saved tasks belonging to another application', () => {
  const tasks: Tables<'application_tasks'>[] = [{ id: 'other', application_id: 'other-app', title: 'Other task', completed: true, due_date: null, user_id: 'student', created_at: '' }];
  expect(applicationTodos(app, tasks).some(t => t.id === 'other')).toBe(false);
 });
 it('matches exactly three personas to only the applied university and program', () => {
  const matches = mentorsForApplication(app, []);
  expect(matches).toHaveLength(3);
  expect(matches.map(m => [m.university_id, m.program, m.ai])).toEqual(Array(3).fill(['waterloo', 'Honours Math', true]));
 });
 it('prioritizes a real mentor in the applied program over fictional personas', () => {
  const mentor: Tables<'profiles'> = { id: 'mentor', full_name: 'Real Mentor', role: 'mentor', university_id: 'waterloo', program: 'Honours Math', year: 'Year 3', bio: null, contact_email: null, created_at: '', updated_at: '', interests: null, linkedin_url: null, onboarding_complete: true };
  const matches = mentorsForApplication(app, [mentor, { ...mentor, id: 'wrong-program', program: 'Engineering' }]);
  expect(matches[0]?.id).toBe('mentor');
  expect(matches[0]?.ai).toBe(false);
  expect(matches.some(m => m.id === 'wrong-program')).toBe(false);
  expect(matches).toHaveLength(3);
 });
 it('adds map visits without adding unvisited universities or duplicate stamps', () => {
  expect(visitedCampusIds(['york', 'waterloo'], [{ university_id: 'University of Waterloo' }])).toEqual(['waterloo', 'york']);
  expect(visitedCampusIds([], [])).toEqual([]);
 });
 it('ties every checklist item to an official deadline', () => {
  const waterloo = applicationTodos(app, []);
  expect(waterloo.every(t => t.due_date)).toBe(true);
  expect(waterloo.find(t => t.title === 'Submit your Admission Information Form (AIF)')?.due_date).toBe('2027-02-15');
  expect(waterloo.find(t => t.suggested)?.due_date).toBe('2027-01-15');
  const other = applicationTodos({ ...app, id: 'york-app', university_id: 'york', program: 'Business' }, []);
  expect(other.every(t => t.due_date === '2027-01-15')).toBe(true);
 });
 it('keeps to-do completion scoped to the specific application', () => {
  const done = { 'math-app:program:0': true };
  expect(applicationTodos(app, [], done).find(t => t.id === 'math-app:program:0')?.completed).toBe(true);
  expect(applicationTodos({ ...app, id: 'other-app' }, [], done).find(t => t.id === 'other-app:program:0')?.completed).toBe(false);
 });
});
