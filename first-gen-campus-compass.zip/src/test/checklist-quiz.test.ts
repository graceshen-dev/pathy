import { describe, expect, it } from 'vitest';
import { campuses } from '@/lib/campuses';
import { campusQuiz, quizPassed } from '@/lib/campus-quiz';
import { checklistPercent, todoDueDate } from '@/lib/checklist-details';
describe('Checklist progress and dates', () => {
 it('calculates percentage from actual completed tasks', () => {
  expect(checklistPercent([{completed:true},{completed:false},{completed:false},{completed:false}])).toBe(25);
  expect(checklistPercent([])).toBe(0);
  expect(checklistPercent([{completed:true}])).toBe(100);
 });
 it('preserves saved due dates and uses explicit personal targets only when set', () => {
  const todo = {id:'math:task',due_date:'2027-02-01'};
  expect(todoDueDate(todo,{})).toBe('2027-02-01');
  expect(todoDueDate(todo,{'math:task':'2027-01-25'})).toBe('2027-01-25');
  expect(todoDueDate({id:'new',due_date:null},{})).toBe('');
 });
});
describe('Campus passport quizzes', () => {
 it.each(campuses.map(c => c.id))('has exactly three simple questions at %s', id => {
  expect(campusQuiz(id)).toHaveLength(3);
  expect(campusQuiz(id).every(q => q.options.length===3 && q.options[q.answer])).toBe(true);
  expect(campusQuiz(id).every(q => new Set(q.options).size === 3)).toBe(true);
  expect(quizPassed(id,campusQuiz(id).map(q => q.answer))).toBe(true);
  expect(quizPassed(id,campusQuiz(id).map((q,i) => i === 1 ? (q.answer+1)%3 : q.answer))).toBe(false);
 });
 it('requires all three correct answers to earn a stamp', () => {
  expect(quizPassed('waterloo',[0,0,2])).toBe(true);
  expect(quizPassed('waterloo',[0,1,2])).toBe(false);
  expect(quizPassed('waterloo',[0,0])).toBe(false);
  expect(quizPassed('unknown',[0,0,2])).toBe(false);
 });
});
