import { describe, expect, it } from 'vitest';
import { checklistPercent, todoDueDate } from '@/lib/checklist-details';
describe('Checklist progress and dates', () => {
 it('calculates percentage from actual completed tasks', () => {
  expect(checklistPercent([{completed:true},{completed:false},{completed:false},{completed:false}])).toBe(25);
  expect(checklistPercent([])).toBe(0);
  expect(checklistPercent([{completed:true}])).toBe(100);
 });
 it('uses only the official deadline attached to the item', () => {
  expect(todoDueDate({due_date:'2027-02-01'})).toBe('2027-02-01');
  expect(todoDueDate({due_date:null})).toBe('');
 });
});
