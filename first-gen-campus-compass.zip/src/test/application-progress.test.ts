import { describe, expect, it } from 'vitest';
import { applicationProgress } from '@/lib/application-progress';
describe('Reference application progress', () => {
  it('shows Waterloo as 60% with three of five steps complete', () => expect(applicationProgress(3, 5)).toBe(60));
  it('shows UofT as 40% with two of five steps complete', () => expect(applicationProgress(2, 5)).toBe(40));
  it('shows McMaster as 25% with one of four steps complete', () => expect(applicationProgress(1, 4)).toBe(25));
});