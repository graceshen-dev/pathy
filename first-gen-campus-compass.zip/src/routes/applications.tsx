import { createFileRoute } from '@tanstack/react-router';
import { ApplicationsScreen } from '@/components/application-journey';
import { pageHead } from '@/components/pathfinder-shell';
export const Route = createFileRoute('/applications')({
 head: () => pageHead('My Applications', 'Keep track of your university application checklist.'),
 component: ApplicationsScreen,
});
