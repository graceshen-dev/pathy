import { createFileRoute } from '@tanstack/react-router';
import { PersonalExploreScreen } from '@/components/personal-journey';
import { pageHead } from '@/components/pathfinder-shell';
export const Route = createFileRoute('/explore')({
 head: () => pageHead('Explore Universities', 'Explore campuses and connect with your university community.'),
 component: PersonalExploreScreen,
});
