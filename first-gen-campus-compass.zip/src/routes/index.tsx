import { createFileRoute } from '@tanstack/react-router';
import { DashboardScreen } from '@/components/personal-journey';
import { pageHead } from '@/components/pathfinder-shell';
export const Route = createFileRoute('/')({
 head: () => pageHead('Pathy University Journey', 'Explore university campuses, collect passport stamps, and track your applications with Pathy.'),
 component: DashboardScreen,
});
