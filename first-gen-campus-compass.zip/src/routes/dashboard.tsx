import { createFileRoute } from '@tanstack/react-router';
import { DashboardScreen } from '@/components/personal-journey';
import { pageHead } from '@/components/pathfinder-shell';
export const Route = createFileRoute('/dashboard')({
 head: () => pageHead('Your University Journey', 'Find your path to university with Pathy.'),
 component: DashboardScreen,
});
