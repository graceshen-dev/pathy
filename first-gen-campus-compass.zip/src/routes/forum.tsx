import { createFileRoute } from '@tanstack/react-router';
import { ForumScreen } from '@/components/community-forum';
import { pageHead } from '@/components/pathfinder-shell';
export const Route = createFileRoute('/forum')({
 head: () => pageHead('Student Forum', 'Connect with Pathy students, ask program questions, and join university communities.'),
 component: ForumScreen,
});
