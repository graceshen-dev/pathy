import { createFileRoute } from '@tanstack/react-router';
import { RemindersScreen } from '@/components/prototype-screens';
import { pageHead } from '@/components/pathfinder-shell';
export const Route = createFileRoute('/reminders')({
 head: () => pageHead('Reminders & Family Updates', 'Manage your university reminders and preview family updates.'),
 component: RemindersScreen,
});
