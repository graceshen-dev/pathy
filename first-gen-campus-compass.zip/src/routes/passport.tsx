import { createFileRoute } from '@tanstack/react-router';
import { PassportScreen } from '@/components/application-journey';
import { pageHead } from '@/components/pathfinder-shell';
export const Route = createFileRoute('/passport')({
 head: () => pageHead('My Passport', 'Collect campus memories and discover matched mentor personas.'),
 component: PassportScreen,
});
