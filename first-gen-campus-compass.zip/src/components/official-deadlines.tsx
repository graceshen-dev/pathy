import { CalendarDays, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { deadlineIntake, deadlinesCheckedOn, officialDeadlinesFor } from '@/lib/official-deadlines';
import { formatDueDate } from '@/lib/checklist-details';
import { resolveCampus } from '@/lib/campuses';

export function OfficialDeadlines({ universityId, program }: { universityId: string; program: string }) {
 const dates = officialDeadlinesFor(universityId, program);
 const campus = resolveCampus(universityId);
 return <section className="official-deadlines border-t border-border pt-5" aria-label="Official admissions deadlines">
  <h2 className="flex items-center gap-2 text-lg"><CalendarDays className="size-5" />Official admissions deadlines</h2>
  {dates.length ? <>
   <p className="device-note">{deadlineIntake} entry · Checked {formatDueDate(deadlinesCheckedOn)}. Choose the date for your applicant category; these are not personal targets.</p>
   <dl className="grid gap-4">{dates.map(date => <div key={date.id} className="border-b border-border pb-4">
    <dt className="text-sm font-bold">{date.title}</dt>
    <dd className="mt-1 text-base font-bold text-success">{formatDueDate(date.date)}</dd>
    <dd className="mt-1 text-xs leading-relaxed text-muted-foreground">{date.audience}</dd>
    <dd><Button asChild variant="link" className="h-auto px-0 py-2 text-xs"><a href={date.source} target="_blank" rel="noreferrer">{date.sourceName}<ExternalLink className="size-3" /></a></Button></dd>
   </div>)}</dl>
   <p className="device-note">A different entry term may have different dates. Confirm changes on the linked official pages and in your applicant portal.</p>
  </> : <><p className="device-note">Official dates have not been verified for this program and entry term.</p>{campus && <Button asChild variant="link" className="h-auto px-0"><a href={campus.site} target="_blank" rel="noreferrer">Check official admissions dates<ExternalLink className="size-3" /></a></Button>}</>}
 </section>;
}