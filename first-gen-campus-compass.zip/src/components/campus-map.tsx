import { useEffect, useRef } from 'react';
import L from 'leaflet';
import { campuses, type Campus } from '@/lib/campuses';
import pip from '@/assets/pat-graduation.png';
type Props = { selected: string; visible: Campus[]; saved: string[]; route?: string[]; onSelect: (id: string) => void };
export default function CampusMap({ selected, visible, saved, route = [], onSelect }: Props) {
 const root = useRef<HTMLDivElement>(null); const map = useRef<L.Map | null>(null); const layer = useRef<L.LayerGroup | null>(null); const pipRef = useRef<L.Marker | null>(null); const trailRef = useRef<L.Polyline | null>(null); const callback = useRef(onSelect); callback.current = onSelect;
  useEffect(() => { if (!root.current) return; const instance = L.map(root.current, { scrollWheelZoom: false, minZoom: 4, maxZoom: 16 });
   instance.fitBounds(L.latLngBounds(campuses.map(c => [c.lat, c.lng] as [number, number])), { padding: [40, 40] });
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>', maxZoom: 19 }).addTo(instance);
  map.current = instance; layer.current = L.layerGroup().addTo(instance);
  const observer = new ResizeObserver(() => instance.invalidateSize()); observer.observe(root.current);
  return () => { observer.disconnect(); instance.remove(); map.current = null; pipRef.current = null; trailRef.current = null; };
 }, []);
 useEffect(() => { const instance = map.current; const markers = layer.current; if (!instance || !markers) return; markers.clearLayers();
  for (const c of visible) {
   const marker = L.marker([c.lat, c.lng], { icon: L.divIcon({ className: 'campus-marker-container', html: `<span class="campus-marker ${c.id === selected ? 'is-selected' : ''} ${saved.includes(c.id) ? 'is-saved' : ''}"><span>${saved.includes(c.id) ? '♥' : '●'}</span></span>`, iconSize: [30, 38], iconAnchor: [15, 38] }), keyboard: true, title: `Explore ${c.name}` }).addTo(markers).on('click', () => callback.current(c.id));
    marker.bindTooltip(c.short, { permanent: c.id === selected, direction: c.id === 'uoft' ? 'bottom' : 'top', offset: [0, c.id === 'uoft' ? 4 : -38], className: 'campus-label' });
  }
  const current = campuses.find(c => c.id === selected);
   if (current && !instance.getBounds().contains([current.lat, current.lng])) instance.panTo([current.lat, current.lng], { animate: !window.matchMedia('(prefers-reduced-motion: reduce)').matches });
 }, [selected, visible, saved, route]);
  useEffect(() => { const instance = map.current; const target = campuses.find(c => c.id === selected); if (!instance || !target) return;
   const b: [number, number] = [target.lat, target.lng];
   if (!pipRef.current) { pipRef.current = L.marker(b, { interactive: false, zIndexOffset: 1000, icon: L.divIcon({ className: 'pip-map-container', html: `<img src="${pip}" alt="Pat the waving fox wearing a graduation cap" />`, iconSize: [64, 74], iconAnchor: [-18, 56] }) }).addTo(instance); return; }
   const marker = pipRef.current; const s = marker.getLatLng(); const a: [number, number] = [s.lat, s.lng]; if (a[0] === b[0] && a[1] === b[1]) return;
   trailRef.current?.remove(); const trail = L.polyline([a], { className: 'journey-route', weight: 4, opacity: .95, lineCap: 'round', lineJoin: 'round', interactive: false, smoothFactor: 0 }).addTo(instance); trailRef.current = trail;
   if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { marker.setLatLng(b); trail.setLatLngs([a, b]); return; }
   const ctrl: [number, number] = [(a[0] + b[0]) / 2 + (b[1] - a[1]) * 0.25, (a[1] + b[1]) / 2 - (b[0] - a[0]) * 0.25];
   const start = performance.now(); const duration = 1100; let frame = 0;
   const step = (now: number) => { const raw = Math.min(1, (now - start) / duration); const t = raw < .5 ? 2 * raw * raw : 1 - Math.pow(-2 * raw + 2, 2) / 2; const u = 1 - t;
    const pt: [number, number] = [u * u * a[0] + 2 * u * t * ctrl[0] + t * t * b[0], u * u * a[1] + 2 * u * t * ctrl[1] + t * t * b[1]]; marker.setLatLng(pt); trail.addLatLng(pt); if (raw < 1) frame = requestAnimationFrame(step); };
   frame = requestAnimationFrame(step); return () => { cancelAnimationFrame(frame); marker.setLatLng(b); };
  }, [selected]);
 return <div ref={root} className="live-campus-map" aria-label="Interactive Ontario university map" />;
}
