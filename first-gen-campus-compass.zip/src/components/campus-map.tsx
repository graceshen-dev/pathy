import { useEffect, useRef } from 'react';
import L from 'leaflet';
import { campuses, type Campus } from '@/lib/campuses';
import pip from '@/assets/pat-graduation.png';
type Props = { selected: string; visible: Campus[]; saved: string[]; onSelect: (id: string) => void };
export default function CampusMap({ selected, visible, saved, onSelect }: Props) {
 const root = useRef<HTMLDivElement>(null); const map = useRef<L.Map | null>(null); const layer = useRef<L.LayerGroup | null>(null); const callback = useRef(onSelect); callback.current = onSelect;
  useEffect(() => { if (!root.current) return; const instance = L.map(root.current, { scrollWheelZoom: false, minZoom: 4, maxZoom: 16 });
   instance.fitBounds(L.latLngBounds(campuses.map(c => [c.lat, c.lng] as [number, number])), { padding: [40, 40] });
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>', maxZoom: 19 }).addTo(instance);
  map.current = instance; layer.current = L.layerGroup().addTo(instance);
  const observer = new ResizeObserver(() => instance.invalidateSize()); observer.observe(root.current);
  return () => { observer.disconnect(); instance.remove(); map.current = null; };
 }, []);
 useEffect(() => { const instance = map.current; const markers = layer.current; if (!instance || !markers) return; markers.clearLayers();
  for (const c of visible) {
   const marker = L.marker([c.lat, c.lng], { icon: L.divIcon({ className: 'campus-marker-container', html: `<span class="campus-marker ${c.id === selected ? 'is-selected' : ''} ${saved.includes(c.id) ? 'is-saved' : ''}"><span>${saved.includes(c.id) ? '♥' : '●'}</span></span>`, iconSize: [30, 38], iconAnchor: [15, 38] }), keyboard: true, title: `Explore ${c.name}` }).addTo(markers).on('click', () => callback.current(c.id));
    marker.bindTooltip(c.short, { permanent: c.id === selected, direction: c.id === 'uoft' ? 'bottom' : 'top', offset: [0, c.id === 'uoft' ? 4 : -38], className: 'campus-label' });
  }
  const current = campuses.find(c => c.id === selected);
   if (current && !instance.getBounds().contains([current.lat, current.lng])) instance.panTo([current.lat, current.lng], { animate: !window.matchMedia('(prefers-reduced-motion: reduce)').matches });
  if (current) L.marker([current.lat, current.lng], { interactive: false, zIndexOffset: 1000, icon: L.divIcon({ className: 'pip-map-container', html: `<img src="${pip}" alt="Pat the waving fox wearing a graduation cap" />`, iconSize: [64, 74], iconAnchor: [-18, 56] }) }).addTo(markers);
  const savedCampuses = campuses.filter(c => saved.includes(c.id)); if (savedCampuses.length > 1) L.polyline(savedCampuses.map(c => [c.lat, c.lng] as [number, number]), { className: 'journey-map-path', dashArray: '6 9', weight: 3 }).addTo(markers);
 }, [selected, visible, saved]);
 return <div ref={root} className="live-campus-map" aria-label="Interactive Ontario university map" />;
}
