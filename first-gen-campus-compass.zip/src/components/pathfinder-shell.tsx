import { Link } from '@tanstack/react-router';
import { Bell, Compass, House, ClipboardList, BookUser, Search, MessageCircle } from 'lucide-react';
import type { ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import logo from '@/assets/pat-graduation.png';
import lightLandscape from '@/assets/landscape-light.jpg.asset.json';
import { useJourney } from '@/hooks/use-journey';

export type Screen = 'dashboard' | 'explore' | 'passport' | 'applications' | 'reminders' | 'forum';
const navigation = [
  { title: 'Home', to: '/dashboard', icon: House, screen: 'dashboard' },
  { title: 'Explore', to: '/explore', icon: Compass, screen: 'explore' },
  { title: 'My Applications', to: '/applications', icon: ClipboardList, screen: 'applications' },
  { title: 'Passport', to: '/passport', icon: BookUser, screen: 'passport' },
  { title: 'Forum', to: '/forum', icon: MessageCircle, screen: 'forum' },
  { title: 'Reminders', to: '/reminders', icon: Bell, screen: 'reminders' },
] as const;
export function pageHead(title: string, description: string) {
  return { meta: [{ title: `${title} | Pathy` }, { name: 'description', content: description }, { property: 'og:title', content: `${title} | Pathy` }, { property: 'og:description', content: description }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' }] };
}
export function PathyShell({ screen, title, children, subtitle }: { screen: Screen; title: string; children: ReactNode; subtitle?: string }) {
  const { preferences } = useJourney();
  return <div className={`pathfinder-app light-sidebar screen-${screen}`}>
    <aside className="app-sidebar">
      <Link to="/dashboard" className="brand"><img src={logo} alt="" /><span>Pathy</span></Link>
      <nav aria-label="Main navigation">{navigation.map(item => <Button key={item.title} asChild variant="ghost" className={`nav-item ${item.screen === screen ? 'current-screen' : ''}`}><Link to={item.to}><item.icon /><span>{item.title}</span></Link></Button>)}</nav>
      <img className="sidebar-landscape" src={lightLandscape.url} alt="" />
    </aside>
    <main className="page-main"><header className="page-header"><div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div><div className="header-tools"><Button variant="ghost" size="icon" asChild aria-label={screen === 'explore' ? 'Search universities' : 'View reminders'}><Link to={screen === 'explore' ? '/explore' : '/reminders'}>{screen === 'explore' ? <Search /> : <Bell />}</Link></Button><span className="profile-avatar" aria-label="Your profile">{preferences.name.trim().charAt(0).toUpperCase() || 'You'}</span></div></header>{children}</main>
  </div>;
}
