import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { ArrowRight, BookOpen, Check, Stamp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import { campusFunFact, reflectionComplete, standoutOptions } from '@/lib/campus-reflection';
import { useJourney } from '@/hooks/use-journey';
import { resolveCampus, type Campus } from '@/lib/campuses';
import { UniversityStamp } from './university-stamp';
import pat from '@/assets/pat-graduation.png';
export function CampusQuiz({ campus }: { campus: Campus }) {
 const { preferences, stamps, earnStamp, visit } = useJourney();
 const [open, setOpen] = useState(false); const [step, setStep] = useState(0); const [standout, setStandout] = useState(''); const [program, setProgram] = useState(''); const [note, setNote] = useState(''); const [done, setDone] = useState(false);
 const earned = preferences.quizStamps.includes(campus.id) || stamps.some(s => resolveCampus(s.university_id)?.id === campus.id);
 function start() { setStep(0); setStandout(''); setProgram(''); setNote(''); setDone(false); setOpen(true); }
 function finish() { const r = { standout, program, note: note.trim(), date: new Date().toISOString().slice(0, 10) }; if (reflectionComplete(r) && earnStamp(campus.id, r)) { visit(campus.id); setDone(true); } }
 const chip = (label: string, value: string, set: (v: string) => void) => <button type="button" key={label} className={`reflect-chip ${value === label ? 'is-on' : ''}`} aria-pressed={value === label} onClick={() => set(label)}>{value === label && <Check />}{label}</button>;
 return <>{earned ? <Button className="campus-quiz-trigger" variant="outline" asChild><Link to="/passport"><Check />In your passport<ArrowRight /></Link></Button> : <Button className="campus-quiz-trigger" onClick={start}><Stamp />Quick check-in · Get your stamp<ArrowRight /></Button>}
 <Dialog open={open} onOpenChange={setOpen}><DialogContent className="campus-quiz-dialog">
  {done ? <div className="quiz-success" role="status"><DialogTitle className="sr-only">Stamp earned</DialogTitle><DialogDescription className="sr-only">{campus.name} added to your passport</DialogDescription>
   <div className="pat-stamping" aria-label={`Pat stamps your passport for ${campus.short}`}><div className="passport-page"><BookOpen className="passport-page-icon" aria-hidden="true" /><UniversityStamp id={campus.id} size="lg" pressed /></div><img className="pat-stamper" src={pat} alt="" aria-hidden="true" /><span className="stamp-thud" aria-hidden="true" /></div>
   <h2>Pat stamped your passport!</h2><p>Your notes on {campus.short} are saved with the stamp.</p><Button asChild><Link to="/passport">Open my passport <ArrowRight /></Link></Button></div>
  : <>
   <div className="reflect-progress" aria-hidden="true"><span className={step >= 0 ? 'on' : ''} /><span className={step >= 1 ? 'on' : ''} /></div>
   {step === 0 ? <>
    <DialogTitle>What stood out at {campus.short}?</DialogTitle><DialogDescription>Pick one — there’s no wrong answer.</DialogDescription>
    <div className="reflect-chips">{standoutOptions.map(o => chip(o, standout, setStandout))}</div>
    <label className="reflect-note">Anything to remember? <span>(optional)</span><input value={note} onChange={e => setNote(e.target.value)} placeholder="e.g. loved the library" maxLength={80} /></label>
    {campusFunFact(campus.id) && <p className="reflect-fact">🦊 Pat’s fun fact: {campusFunFact(campus.id)}</p>}
    <Button disabled={!standout} onClick={() => setStep(1)}>Next <ArrowRight /></Button>
   </> : <>
    <DialogTitle>Which program caught your eye?</DialogTitle><DialogDescription>Choose one you’d like to learn more about.</DialogDescription>
    <div className="reflect-chips">{[...campus.programs, 'Not sure yet'].map(o => chip(o, program, setProgram))}</div>
    <div className="reflect-actions"><Button variant="ghost" onClick={() => setStep(0)}>Back</Button><Button disabled={!program} onClick={finish}><Stamp />Stamp my passport</Button></div>
   </>}
  </>}
 </DialogContent></Dialog></>;
}
