import type { CSSProperties } from 'react';
import { campusFacts } from '@/lib/campus-facts';
import { resolveCampus } from '@/lib/campuses';
export function UniversityStamp({ id, size = 'md', pressed = false }: { id: string; size?: 'md' | 'lg'; pressed?: boolean }) {
 const campus = resolveCampus(id); const f = campusFacts[campus?.id ?? id];
 const style = { '--uni': f?.color ?? 'var(--success)', '--uni-accent': f?.accent ?? 'var(--card)' } as CSSProperties;
 const tilt = ((campus?.id ?? id).length % 5) * 3 - 6;
 return <div className={`uni-stamp uni-stamp-${size} ${pressed ? 'is-pressed' : ''}`} style={{ ...style, rotate: `${tilt}deg` }} aria-label={`${campus?.name ?? id} passport stamp`}>
  <svg viewBox="0 0 200 200" className="uni-stamp-ring" aria-hidden="true"><defs><path id={`arc-${id}`} d="M100,100 m-74,0 a74,74 0 1,1 148,0 a74,74 0 1,1 -148,0" /></defs><circle cx="100" cy="100" r="94" /><circle cx="100" cy="100" r="60" className="inner" /><text><textPath href={`#arc-${id}`} startOffset="50%" textAnchor="middle">{`${(campus?.name ?? id).toUpperCase()} · ${campus?.city.toUpperCase() ?? ''} · `}</textPath></text></svg>
  <div className="uni-stamp-core"><span className="uni-stamp-symbol" aria-hidden="true">{f?.symbol ?? '🎓'}</span><strong>{f?.monogram ?? campus?.short}</strong><small>EST. {f?.founded ?? '—'}</small></div>
 </div>;
}
