import { useEffect, useState } from 'react';
import { ArrowUp, MessageCircle, Plus, Send, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import { PathyShell } from './pathfinder-shell';
import { useJourney } from '@/hooks/use-journey';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';
import { campuses, resolveCampus } from '@/lib/campuses';
const faqs = [
 { question: 'How do I check my program requirements?', answer: 'Use the official admissions page for your university and exact program. Prerequisites, supplements, and deadlines can differ by program and year.' },
 { question: 'Where can a first-gen student find support?', answer: 'Ask the university’s student-support office about first-generation advising, financial aid, peer mentorship, and transition programs.' },
 { question: 'Are the student personas real mentors?', answer: 'People labeled “Fictional AI student persona” are not enrolled students. Registered student mentors are shown separately. Live messaging and booking are not connected yet.' },
];
export function ForumScreen() {
 const { userId, signedIn, preferences, applications } = useJourney();
 const [community, setCommunity] = useState('general'); const [posts, setPosts] = useState<Tables<'forum_posts'>[]>([]); const [comments, setComments] = useState<Tables<'forum_comments'>[]>([]); const [votes, setVotes] = useState<Tables<'forum_votes'>[]>([]);
 const [loading, setLoading] = useState(true); const [error, setError] = useState(''); const [busy, setBusy] = useState(false); const [composing, setComposing] = useState(false); const [selected, setSelected] = useState<Tables<'forum_posts'> | null>(null); const [title, setTitle] = useState(''); const [body, setBody] = useState(''); const [reply, setReply] = useState('');
 async function refresh() {
  setLoading(true);
  const [p,c,v] = await Promise.all([supabase.from('forum_posts').select('*').order('created_at', { ascending: false }), supabase.from('forum_comments').select('*').order('created_at'), supabase.from('forum_votes').select('*')]);
  if (p.error || c.error || v.error) setError('Community discussions could not be loaded. Please try again.'); else { setPosts(p.data ?? []); setComments(c.data ?? []); setVotes(v.data ?? []); }
  setLoading(false);
 }
 useEffect(() => { void refresh(); }, [userId]);
 const author = preferences.name.trim() || 'Pathy student';
 async function createPost() {
  if (!userId || !title.trim() || !body.trim()) return; setBusy(true); setError('');
  const result = await supabase.from('forum_posts').insert({ user_id: userId, author_name: author, community, title: title.trim(), body: body.trim() });
  if (result.error) setError('Your discussion could not be posted. Your draft is still here.'); else { setComposing(false); setTitle(''); setBody(''); await refresh(); } setBusy(false);
 }
 async function createReply() {
  if (!userId || !selected || !reply.trim()) return; setBusy(true); setError('');
  const result = await supabase.from('forum_comments').insert({ user_id: userId, author_name: author, post_id: selected.id, body: reply.trim() });
  if (result.error) setError('Your reply could not be posted.'); else { setReply(''); await refresh(); } setBusy(false);
 }
 async function vote(postId: string) {
  if (!userId) return; setBusy(true);
  const existing = votes.find(v => v.user_id === userId && v.post_id === postId);
  const result = existing ? await supabase.from('forum_votes').delete().eq('post_id', postId).eq('user_id', userId) : await supabase.from('forum_votes').insert({ post_id: postId, user_id: userId, value: 1 });
  if (result.error) setError('Your vote could not be saved.'); else await refresh(); setBusy(false);
 }
 async function removePost(post: Tables<'forum_posts'>) {
  if (post.user_id !== userId || !window.confirm('Delete this discussion?')) return; setBusy(true);
  const result = await supabase.from('forum_posts').delete().eq('id', post.id).eq('user_id', userId);
  if (result.error) setError('Your discussion could not be deleted.'); else { setSelected(null); await refresh(); } setBusy(false);
 }
 const visible = posts.filter(p => community === 'general' ? p.community === 'general' || p.community === 'overall' : resolveCampus(p.community)?.id === community || p.community === community);
 return <PathyShell screen="forum" title="Forum" subtitle="A place for questions, shared experiences, and your university community.">
 <div className="forum-toolbar"><label>Community<select aria-label="Community" value={community} onChange={e => setCommunity(e.target.value)}><option value="general">All Pathy · General community</option>{campuses.map(c => <option key={c.id} value={c.id}>{c.name}{applications.some(a => resolveCampus(a.university_id)?.id === c.id) ? ' · Applied' : ''}</option>)}</select></label><Button disabled={!signedIn} onClick={() => setComposing(true)}><Plus />New discussion</Button></div>
 {!signedIn && <p className="device-note">Sign in to post, reply, or vote.</p>}{error && <p role="alert" className="journey-error">{error}</p>}
 <div className="forum-layout"><section aria-label="Community discussions">{loading ? <p role="status">Loading discussions…</p> : !visible.length ? <div className="journey-empty"><MessageCircle /><h2>No discussions here yet</h2><p>What would you like to ask your community?</p></div> : visible.map(post => <article className="forum-post" key={post.id}><div className="forum-vote"><Button variant="ghost" size="icon" aria-label={`Upvote ${post.title}`} aria-pressed={votes.some(v => v.user_id === userId && v.post_id === post.id)} disabled={!signedIn || busy} onClick={() => void vote(post.id)}><ArrowUp /></Button><strong>{votes.filter(v => v.post_id === post.id).reduce((sum,v) => sum + v.value, 0)}</strong></div><div><p className="forum-byline">{post.author_name} · {new Date(post.created_at).toLocaleDateString()}</p><Button variant="link" className="forum-post-title" onClick={() => setSelected(post)}>{post.title}</Button><p className="forum-excerpt">{post.body}</p><Button variant="ghost" onClick={() => setSelected(post)}><MessageCircle />{comments.filter(c => c.post_id === post.id).length} replies</Button></div></article>)}</section><aside className="forum-faq"><h2>Frequently asked</h2>{faqs.map(f => <details key={f.question}><summary>{f.question}</summary><p>{f.answer}</p></details>)}</aside></div>
 <Dialog open={composing} onOpenChange={setComposing}><DialogContent><DialogTitle>New discussion</DialogTitle><DialogDescription>{resolveCampus(community)?.name ?? 'General Pathy community'}</DialogDescription><form className="journey-form" onSubmit={e => {e.preventDefault(); void createPost();}}><label>Title<input aria-label="Discussion title" maxLength={180} value={title} onChange={e => setTitle(e.target.value)} required /></label><label>Your question<textarea aria-label="Discussion body" rows={5} value={body} onChange={e => setBody(e.target.value)} required /></label>{error && <p role="alert">{error}</p>}<Button type="submit" disabled={busy || !title.trim() || !body.trim()}><Send />{busy ? 'Posting…' : 'Post discussion'}</Button></form></DialogContent></Dialog>
 <Dialog open={Boolean(selected)} onOpenChange={() => setSelected(null)}><DialogContent className="forum-thread"><DialogTitle>{selected?.title}</DialogTitle><DialogDescription>{selected?.author_name} · {resolveCampus(selected?.community ?? '')?.name ?? 'Pathy community'}</DialogDescription><p className="thread-body">{selected?.body}</p>{selected?.user_id === userId && <Button variant="ghost" disabled={busy} onClick={() => selected && void removePost(selected)}><Trash2 />Delete discussion</Button>}<div className="thread-replies">{comments.filter(c => c.post_id === selected?.id).map(c => <article key={c.id}><strong>{c.author_name}</strong><p>{c.body}</p></article>)}</div>{signedIn && <form className="journey-form" onSubmit={e => {e.preventDefault(); void createReply();}}><textarea aria-label="Your reply" placeholder="Add your reply" rows={3} value={reply} onChange={e => setReply(e.target.value)} required /><Button disabled={busy || !reply.trim()} type="submit"><Send />Post reply</Button></form>}{error && <p role="alert">{error}</p>}</DialogContent></Dialog>
 </PathyShell>;
}
