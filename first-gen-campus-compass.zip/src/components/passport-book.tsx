import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { ArrowLeft, ArrowRight, GraduationCap, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useJourney } from '@/hooks/use-journey';
import { resolveCampus } from '@/lib/campuses';
import { formatDueDate } from '@/lib/checklist-details';
import { UniversityStamp } from './university-stamp';
import pat from '@/assets/pat-graduation.png';
type Page = { kind: 'id' } | { kind: 'stamp'; id: string } | { kind: 'blank' };
export function PassportBook({ visits }: { visits: string[] }) {
 const { preferences, update } = useJourney(); const [open, setOpen] = useState(false); const [spread, setSpread] = useState(0); const [dir, setDir] = useState<'next' | 'prev'>('next');
 const pages: Page[] = [{ kind: 'id' }, ...visits.map(id => ({ kind: 'stamp' as const, id })), { kind: 'blank' }]; if (pages.length % 2) pages.push({ kind: 'blank' });
 const spreads = pages.length / 2; const turn = (d: number) => { setDir(d > 0 ? 'next' : 'prev'); setSpread(s => Math.min(spreads - 1, Math.max(0, s + d))); };
 if (!open) return <button type="button" className="passport-cover" onClick={() => setOpen(true)} aria-label="Open my passport">
  <span className="cover-crest"><GraduationCap strokeWidth={1.6} /></span><strong>PASSPORT</strong><span className="cover-sub">Pathy · Ontario Universities</span>{preferences.name && <span className="cover-name">{preferences.name}</span>}<img src={pat} alt="" /><span className="cover-count">{visits.length} {visits.length === 1 ? 'stamp' : 'stamps'} · tap to open</span></button>;
 const renderPage = (p: Page, side: 'left' | 'right') => <div className={`passport-leaf leaf-${side}`}>
  {p.kind === 'id' ? <div className="leaf-id"><span className="leaf-label">PASSPORT HOLDER</span><img src={pat} alt="Pat, your guide" /><label className="leaf-name"><span>Your name</span><input aria-label="Your name on passport" placeholder="Write your name" value={preferences.name} maxLength={40} onChange={e => update({ name: e.target.value })} /></label><span>{preferences.program || 'Exploring programs'}</span><dl><div><dt>Stamps</dt><dd>{visits.length}</dd></div><div><dt>Guide</dt><dd>Pat 🦊</dd></div></dl></div>
  : p.kind === 'stamp' ? (() => { const c = resolveCampus(p.id); const r = preferences.reflections?.[c?.id ?? p.id]; return <div className="leaf-stamp"><UniversityStamp id={p.id} /><h3>{c?.name ?? p.id}</h3>{r ? <ul><li><span>Stood out</span>{r.standout}</li><li><span>Program</span>{r.program}</li>{r.note && <li><span>Note</span>“{r.note}”</li>}<li><span>Visited</span>{formatDueDate(r.date)}</li></ul> : <p className="device-note">Stamp saved to your account.</p>}<Link to="/explore" onClick={() => update({ selected: c?.id ?? p.id })} className="leaf-link">See on map <ArrowRight className="size-3" /></Link></div>; })()
  : <div className="leaf-blank"><MapPin /><p>Room for your next stamp</p><Button asChild size="sm" variant="outline"><Link to="/explore">Explore a campus</Link></Button></div>}
  <span className="leaf-number">{pages.indexOf(p) + 1}</span></div>;
 return <div className="passport-book-wrap"><div key={spread} className={`passport-book turn-${dir}`}>{renderPage(pages[spread * 2]!, 'left')}{renderPage(pages[spread * 2 + 1]!, 'right')}</div>
  <div className="passport-nav"><Button variant="outline" size="sm" onClick={() => spread ? turn(-1) : setOpen(false)}><ArrowLeft />{spread ? 'Previous' : 'Close'}</Button><span>Page {spread + 1} of {spreads}</span><Button variant="outline" size="sm" disabled={spread >= spreads - 1} onClick={() => turn(1)}>Next<ArrowRight /></Button></div></div>;
}
