import { campusPhotos } from '@/lib/campus-photos';
export function CampusPhoto({ id }: { id: string }) {
 const photo = campusPhotos[id]; if (!photo) return null;
 return <figure className="campus-photo"><img src={photo.url} alt={photo.alt} /><figcaption>Photo: <a href={photo.source} target="_blank" rel="noreferrer">{photo.credit}</a></figcaption></figure>;
}
