import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { ArrowRight, BookOpen, Check, Compass, GraduationCap, MapPin, MessageCircle, Users, CalendarDays, Pencil, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import { CampusPhoto } from './campus-photo';
import { OfficialDeadlines } from './official-deadlines';
import { PathyShell } from './pathfinder-shell';
import { useJourney } from '@/hooks/use-journey';
import { resolveCampus } from '@/lib/campuses';
import { applicationTodos, mentorsForApplication, visitedCampusIds, type MentorMatch } from '@/lib/journey-personalization';
import { checklistPercent, todoDueDate, formatDueDate } from '@/lib/checklist-details';
import type { JourneyTodo } from '@/lib/journey-personalization';
import pat from '@/assets/pat-graduation.png';
import aisha from '@/assets/aisha.jpg.asset.json';
import daniel from '@/assets/daniel.jpg.asset.json';
import priya from '@/assets/priya.jpg.asset.json';
function EmptyApplications() { return <div className="journey-empty"><GraduationCap /><h2>No applications saved yet</h2><p>Your applied universities and programs will appear here when they are saved to your account.</p><Button asChild variant="outline"><Link to="/explore">Explore campuses <ArrowRight /></Link></Button></div>; }
function ProgressRing({ percent }: { percent: number }) {
 return <span className="checklist-ring" aria-label={`${percent}% complete`}><svg viewBox="0 0 72 72" aria-hidden="true"><circle className="ring-track" cx="36" cy="36" r="29" /><circle className="ring-value" cx="36" cy="36" r="29" pathLength="100" strokeDasharray={`${percent} 100`} /></svg><strong>{percent}%</strong></span>;
}
export function ApplicationsScreen() {
 const { applications, tasks, preferences, update, loading, error } = useJourney();
 const [selected, setSelected] = useState(''); const [editing, setEditing] = useState<JourneyTodo | null>(null); const [dateDraft, setDateDraft] = useState(''); const [essay, setEssay] = useState(false); const [draft, setDraft] = useState(''); const [feedback, setFeedback] = useState('');
 const app = applications.find(a => a.id === selected) ?? applications[0];
 const todos = app ? applicationTodos(app, tasks, preferences.todoDone) : [];
 const deadlines = todos.map(t => ({ ...t, date: todoDueDate(t, preferences.todoDates) })).filter(t => t.date && !t.completed).sort((a,b) => a.date.localeCompare(b.date));
 function editDate(todo: JourneyTodo) { setEditing(todo); setDateDraft(todoDueDate(todo, preferences.todoDates).slice(0,10)); }
 return <PathyShell screen="applications" title="My Applications" subtitle="Your programs. Your next steps.">
 {error && <p role="alert" className="journey-error">{error}</p>}
 {loading ? <p role="status">Loading your applications…</p> : !app ? <EmptyApplications /> : <>
 <div className="application-summary-row">{applications.map(a => { const list = applicationTodos(a, tasks, preferences.todoDone); return <Button key={a.id} variant="outline" className={`application-summary ${a.id === app.id ? 'selected' : ''}`} onClick={() => setSelected(a.id)}><span className="campus-symbol"><GraduationCap /></span><span className="summary-school"><strong>{resolveCampus(a.university_id)?.short ?? a.university_id}</strong><small>{a.program}</small><span>{checklistPercent(list)}% complete</span></span><ProgressRing percent={checklistPercent(list)} /></Button>; })}</div>
 <div className="checklist-reference-layout"><section className="program-todos"><div className="section-heading"><div><span className="journey-eyebrow">{resolveCampus(app.university_id)?.name ?? app.university_id}</span><h2>{app.program} checklist</h2></div><span className="checklist-count">{todos.filter(t => t.completed).length}/{todos.length}</span></div>
 {todos.map(todo => { const date = todoDueDate(todo, preferences.todoDates); return <div className="dated-todo" key={todo.id}><label className="checklist-row"><input type="checkbox" aria-label={todo.title} checked={todo.completed} onChange={e => update({ todoDone: { ...preferences.todoDone, [todo.id]: e.target.checked } })} /><span className="custom-check">{todo.completed && <Check />}</span><span>{todo.title}{todo.suggested && <small className="todo-origin">Program guidance</small>}</span></label><Button variant="ghost" className={`todo-date-button ${date ? 'has-date' : ''}`} aria-label={`Set due date for ${todo.title}`} onClick={() => editDate(todo)}><CalendarDays /><span>{date ? formatDueDate(date) : 'Set due date'}<small>{date ? (preferences.todoDates[todo.id] !== undefined ? 'My target' : 'Saved due date') : 'My target'}</small></span><Pencil /></Button></div>; })}
 <p className="device-note">Changes stay on this device. Personal targets are not official university deadlines.</p></section>
 <aside className="checklist-reference-side"><OfficialDeadlines universityId={app.university_id} program={app.program} /><CampusPhoto id={resolveCampus(app.university_id)?.id ?? app.university_id} /><section className="essay-guidance"><div><h2>Essay helper</h2><p>Your words, your story.</p><Button onClick={() => setEssay(true)}>Get feedback <ArrowRight /></Button></div><img src={pat} alt="Pat in his graduation cap" /></section><section className="upcoming-checklist-dates"><h2><CalendarDays />Upcoming deadlines</h2>{deadlines.length ? deadlines.slice(0,4).map(t => <Button key={t.id} variant="ghost" className="upcoming-date" onClick={() => editDate(t)}><span className="date-tile">{new Date(`${t.date.slice(0,10)}T12:00:00`).toLocaleDateString('en-CA', {month:'short'})}<strong>{t.date.slice(8,10)}</strong></span><span>{t.title}<small>{preferences.todoDates[t.id] !== undefined ? 'My target' : 'Saved due date'}</small></span></Button>) : <p>No dates set yet.</p>}<p className="device-note">Confirm official dates with your university.</p>{resolveCampus(app.university_id) && <Button asChild variant="link"><a href={resolveCampus(app.university_id)?.site} target="_blank" rel="noreferrer">Admissions deadlines <ArrowRight /></a></Button>}</section><Button asChild variant="outline"><Link to="/passport"><Users />Your program people <ArrowRight /></Link></Button></aside></div></>}
 <Dialog open={Boolean(editing)} onOpenChange={() => setEditing(null)}><DialogContent><DialogTitle>Set a due date</DialogTitle><DialogDescription>{editing?.title}</DialogDescription><form className="journey-form" onSubmit={e => { e.preventDefault(); if (!editing) return; update({ todoDates: { ...preferences.todoDates, [editing.id]: dateDraft } }); setEditing(null); }}><label>My target date<input aria-label="My target date" type="date" value={dateDraft} onChange={e => setDateDraft(e.target.value)} /></label><p className="device-note">A personal planning date, not an official admissions deadline.</p><Button type="submit"><Check />Save date</Button></form></DialogContent></Dialog>
 <Dialog open={essay} onOpenChange={setEssay}><DialogContent><DialogTitle>Essay helper</DialogTitle><DialogDescription>Sample guidance only; live AI review is not connected.</DialogDescription><textarea aria-label="Your essay draft" rows={6} value={draft} onChange={e => setDraft(e.target.value)} placeholder="Paste your essay draft…" /><Button disabled={!draft.trim()} onClick={() => setFeedback(`For ${app?.program ?? 'your program'}, use a specific experience, describe what you learned, and explain your interest in the program. This is sample guidance, not a review of your draft.`)}><Sparkles />Get sample guidance</Button>{feedback && <p>{feedback}</p>}</DialogContent></Dialog>
 </PathyShell>;
}
export function PassportScreen() {
 const { applications, mentors, preferences, stamps, update, loading, error } = useJourney();
 const [selectedApp, setSelectedApp] = useState(''); const [mentor, setMentor] = useState<MentorMatch | null>(null);
 const app = applications.find(a => a.id === selectedApp) ?? applications[0];
 const visits = visitedCampusIds(preferences.quizStamps, stamps);
 const matches = app ? mentorsForApplication(app, mentors) : [];
 return <PathyShell screen="passport" title="My Passport" subtitle="Places explored. People who understand your path.">
 {error && <p role="alert" className="journey-error">{error}</p>}
 {loading ? <p role="status">Loading your passport…</p> : <div className="personal-passport-layout"><section className="passport-journey"><div className="section-heading"><div><span className="journey-eyebrow">YOUR JOURNEY WITH PAT</span><h2>{visits.length} passport {visits.length === 1 ? 'stamp' : 'stamps'}</h2></div><BookOpen /></div><p className="device-note">Quiz stamps saved on this device, alongside your saved passport entries—not verified in-person visits.</p>
 <div className="passport-stamps">{visits.map(id => { const campus = resolveCampus(id); return <Button key={id} asChild variant="outline" className="passport-stamp" onClick={() => update({ selected: campus?.id ?? id })}><Link to="/explore" aria-label={`Open ${campus?.name ?? id} on map`}><Compass /><strong>{campus?.short ?? id}</strong><span>{campus?.city ?? 'Campus'}</span><small>STAMP EARNED <ArrowRight /></small></Link></Button>; })}</div>
 {!visits.length && <div className="journey-empty"><MapPin /><h3>Your first stamp is waiting</h3><p>Answer three campus quiz questions correctly to earn your stamp.</p></div>}
 <div className="passport-footer"><img src={pat} alt="Pat, your passport companion" /><Button asChild><Link to="/explore"><MapPin />Continue on the map <ArrowRight /></Link></Button></div></section>
 <section className="passport-program-mentors"><h2>Your program people</h2>{!app ? <EmptyApplications /> : <><label className="program-select-label">Applied program<select aria-label="Applied program" value={app.id} onChange={e => setSelectedApp(e.target.value)}>{applications.map(a => <option key={a.id} value={a.id}>{resolveCampus(a.university_id)?.short ?? a.university_id} · {a.program}</option>)}</select></label>
 {matches.map(m => <article className="mentor-card" key={m.id}>{m.ai ? <img src={[aisha.url, daniel.url, priya.url][m.portraitIndex]} alt={`${m.name}, fictional AI persona`} /> : <span className="real-mentor-avatar"><Users /></span>}<div><h3>{m.name}</h3><p>{m.year} · {m.program}</p><p>{resolveCampus(m.university_id)?.name ?? m.university_id}</p><span className="match-badge">Your applied program</span><small className="persona-label">{m.ai ? 'Fictional AI student persona · not an enrolled mentor' : 'Registered student mentor'}</small><Button variant="outline" onClick={() => setMentor(m)}><MessageCircle />Meet {m.name.split(' ')[0]}</Button></div></article>)}</>}
 </section></div>}
 {mentor && <Dialog open onOpenChange={() => setMentor(null)}><DialogContent><DialogTitle>Meet {mentor.name}</DialogTitle><DialogDescription>{mentor.ai ? `${mentor.name} is a fictional AI student persona for ${mentor.program}, not an enrolled mentor. Live AI chat and mentor booking are not connected.` : `${mentor.name} studies ${mentor.program}. Messaging and mentor booking are not connected yet.`}</DialogDescription><p>{mentor.bio}</p><Button asChild variant="outline"><Link to="/forum">Ask the community <ArrowRight /></Link></Button></DialogContent></Dialog>}
 </PathyShell>;
}
