# Desktop prototype screens
- [x] Recreate Explore, Passport, Applications, and Reminders from desktop references 2–5.
- [x] Add matching imagery and working frontend controls without pretending external services are connected.
- [x] Verify all four screens at desktop and mobile sizes, run relevant tests, and commit.

# Personalized dashboard and map
- [x] Replace the dashboard alias with a personalized journey dashboard and editable preferences.
- [x] Replace the screenshot map with geographic interactive campus markers and a corrected orange-beanie fox.
- [x] Verify preference persistence, campus selection, saved schools, and desktop/mobile rendering; commit changes.
# Pathy and Pat
- [x] Rename the site Pathy and the fox Pat throughout the interface and page titles.
- [x] Replace the beanie with a graduation cap on the dashboard, map, and site logo.
- [x] Verify the updated branding and mascot on screen, then commit.

# Application-based passport and forum
- [x] Replace sample applications with real applied universities and program-specific to-dos.
- [x] Match passport mentors to applied programs and connect stamps to campus map visits.
- [x] Restore the in-app Forum with university communities and FAQs.
- [x] Test personalization rules and verify the signed-in journey end to end; commit.

# Checklist deadlines and quiz stamps
- [x] Add completion rings, due-date editing, and an upcoming-deadlines view inspired by the prototype.
- [x] Add real campus photographs for all five universities.
- [x] Add three-question campus quizzes; require all correct answers for new passport stamps.
- [x] Verify deadline persistence, percentages, quiz retries, stamp readback, and mobile layouts; commit.

# Ontario universities and stamp celebration
- [x] Expand the geographic catalogue and three-question quizzes to all 23 publicly assisted Ontario universities.
- [x] Animate earned passport stamps, respecting reduced-motion preferences.
- [x] Verify campus selection, quiz-to-passport flow, and narrow layouts; commit.

# Official online deadlines and stamp label
- [x] Research official Fall 2027 Waterloo Honours Math deadlines and show sourced dates with intake and eligibility.
- [x] Replace the earned quiz button’s replay label with “Stamp earned.”
- [x] Test date scoping and verify the signed-in checklist and earned-stamp button; commit.
