create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'student',
  program text, interests text, university_id text, year text, bio text,
  contact_email text, linkedin_url text,
  onboarding_complete boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.profiles to authenticated;
grant insert (id, full_name, program, interests, university_id, year, bio, contact_email, linkedin_url, onboarding_complete) on public.profiles to authenticated;
grant update (full_name, program, interests, university_id, year, bio, contact_email, linkedin_url, onboarding_complete, updated_at) on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "read own or mentor profiles" on public.profiles for select to authenticated using (id = auth.uid() or role = 'mentor');
create policy "insert own profile" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  university_id text not null,
  program text not null,
  applied_on date not null default current_date,
  created_at timestamptz not null default now()
);
create table public.application_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  application_id uuid not null references public.applications(id) on delete cascade,
  title text not null,
  completed boolean not null default false,
  due_date date,
  created_at timestamptz not null default now()
);
create table public.passport_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  university_id text not null,
  created_at timestamptz not null default now()
);
create table public.ai_access_state (
  user_id uuid primary key,
  reason text not null
);
create table public.forum_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  author_name text not null,
  community text not null default 'general',
  title text not null,
  body text not null,
  created_at timestamptz not null default now()
);
create table public.forum_comments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  post_id uuid not null references public.forum_posts(id) on delete cascade,
  author_name text not null,
  body text not null,
  created_at timestamptz not null default now()
);
create table public.forum_votes (
  post_id uuid not null references public.forum_posts(id) on delete cascade,
  user_id uuid not null,
  value integer not null,
  primary key (post_id, user_id)
);
create table public.mentor_connections (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null,
  mentor_id uuid not null references public.profiles(id) on delete cascade,
  student_email text not null,
  message text not null,
  created_at timestamptz not null default now()
);

grant select, insert, update, delete on public.applications, public.application_tasks, public.passport_entries, public.forum_posts, public.forum_comments, public.forum_votes, public.mentor_connections to authenticated;
grant select on public.ai_access_state to authenticated;
grant select on public.forum_posts, public.forum_comments, public.forum_votes to anon;
grant all on public.applications, public.application_tasks, public.passport_entries, public.ai_access_state, public.forum_posts, public.forum_comments, public.forum_votes, public.mentor_connections to service_role;

alter table public.applications enable row level security;
alter table public.application_tasks enable row level security;
alter table public.passport_entries enable row level security;
alter table public.ai_access_state enable row level security;
alter table public.forum_posts enable row level security;
alter table public.forum_comments enable row level security;
alter table public.forum_votes enable row level security;
alter table public.mentor_connections enable row level security;

create policy "own applications" on public.applications for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own tasks" on public.application_tasks for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own passport" on public.passport_entries for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own ai state" on public.ai_access_state for select to authenticated using (user_id = auth.uid());

create policy "anyone reads posts" on public.forum_posts for select to anon, authenticated using (true);
create policy "write own posts" on public.forum_posts for insert to authenticated with check (user_id = auth.uid());
create policy "update own posts" on public.forum_posts for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "delete own posts" on public.forum_posts for delete to authenticated using (user_id = auth.uid());
create policy "anyone reads comments" on public.forum_comments for select to anon, authenticated using (true);
create policy "write own comments" on public.forum_comments for insert to authenticated with check (user_id = auth.uid());
create policy "delete own comments" on public.forum_comments for delete to authenticated using (user_id = auth.uid());
create policy "anyone reads votes" on public.forum_votes for select to anon, authenticated using (true);
create policy "write own votes" on public.forum_votes for insert to authenticated with check (user_id = auth.uid());
create policy "delete own votes" on public.forum_votes for delete to authenticated using (user_id = auth.uid());

create policy "parties read connections" on public.mentor_connections for select to authenticated using (student_id = auth.uid() or mentor_id = auth.uid());
create policy "students create connections" on public.mentor_connections for insert to authenticated with check (student_id = auth.uid());